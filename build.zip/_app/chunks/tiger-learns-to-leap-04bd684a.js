const e="A Tiger Learns to Leap",t=[{Type:"text",Text:`Shamsher Singh was on his way to consummate his marriage. To set the record straight, he wasn\u2019t married to Bhanu yet. But their parents had met and decided that they were a perfect match for one another. And then Shamsher\u2019s family pandit had adjudicated that it should happen within the next two months. Or else Shamsher\u2019s planets were going to shift and take new positions (as though they aren\u2019t planets but teenagers in heat, switching from missionary to cowgirl!) Once the planets had moved, they would ensure Shamsher turned into a brahmachari and never experience the happiness of starting a family in this lifetime. Why the planets were so interested in his sex and family life was a question no one bothered to ask the pandit.\r
\r
\r
Nearly nine of the twenty-six years that Shamsher had already been on this planet, he had spent being six feet and two inches of girth and muscles. Shamsher was no hunk, but he worked so hard with the other colony boys at the local gym every day that his ripped arms were always popping out of the half-sleeve colourful shirts he mostly wore. Even though he had become an expert at all kinds of tough things which were expected from someone like him \u2014 from street fights to bar brawls \u2014 his luck with women was yet to turn in his favour. In other words, he was yet to meet a woman who didn\u2019t make him afraid. \r
\r
\r
Bhanu was unlike the other girls he had met during his school and college days. Even before their families were able to match their horoscopes and seal their fate, she had pulled him close to slide her hand through the gap between his neck and the kurta he was wearing to feel the skin around his chest.\r
\r
\r
---\r
\r
\r
This was supposed to be a new beginning for him, a day of discovery, a day of great freedom. \r
Bhanu had been intimate with a few other boys she had liked before, and while relaying those encounters to Shamsher she had also made it clear that she won\u2019t marry him before being sure of their compatibility in bed. He had felt a little hurt but in order to show appreciation for her truthfulness, Shamsher said to her he was grateful for her honesty and confession. To which the ever-feisty Bhanu had replied, \u201CThere\u2019s nothing to confess, Shera. My life choices are not a criminal act.\u201D \r
\r
\r
It was the day Shamsher was to consummate his love, Bhanu waiting for him on the roof of their two-storied government quarter in a skimpy skirt and a top with the word \u201Cbebe\u201D written on it. Of all days in the world, on that very day Shamsher got fired from his job. He was a door-to-door salesman in a company that manufactured detergents, but they were digitizing their operations and much of their sales force was suddenly becoming redundant. Shamsher\u2019s services were no longer required. \r
\r
\r
Outside his boss\u2019 room, the walls of the office building had recently ben painted pristine white. Shamsher had kept his cool for far too long by the time he stepped out of the ritzy but tasteless cabin. So, when he walked out and saw his soon to be ex-colleagues staring at him in anticipation of an adequate response that suited his persona, he decided to leave an imprint of his fist on one of the walls as a permanent marker of sorts. Or perhaps as a reminder for those he was leaving behind, that eventually everybody has to lose.\r
\r
\r
---\r
\r
\r
The first thing he wanted to do was tell Bhanu. She deserved to know that she was about to marry a man whose future, and present, was uncertain. But, when he climbed two-storied length of PVC pipes and reached the terrace where she stood in the twilight hour, ready for him, all he could see were her practiced lips, shining under layers of cheap maroon lipstick.\r
\r
\r
He felt her up without even undressing her, like a sea creature experiencing land for the first time. Her roundness and her sharp edges, hissing past each crest and trough with both an unexplainable hesitation and an unmeasured eagerness. She allowed him to have his play, oddly charmed by his inexperience. When Bhanu grabbed his head by his hair and shoved her tongue inside his mouth, he didn\u2019t know what to do with his own tongue at first. Shamsher always wondered how kissing someone in the mouth works, because there\u2019s only enough space for one tongue inside his mouth. How do two tongues fit inside the same mouth at once? But Bhanu led from the front and soon his teeth and his tongue and his gums and blood vessels, they all knew how to tango.\r
\r
\r
When she paused to come up for air, she giggled noticing how Shamsher had his eyes open the entire time. \u201CYou know nothing, Shera,\u201D she said. Some kind of an ancient, genuine affection reflected in her voice when she said those words. Only someone who\u2019s likely to give you shelter would speak like that, he thought. This had to be the right time. \r
\u201CI have something to share,\u201D he whispered in her ear. \r
She smirked, \u201CI know you\u2019ve never done it before; it\u2019s not rocket science I promise.\u201D \r
\u201CIt\u2019s not that. I mean, it\u2019s true but\u2026\u201D\r
\u201CAren\u2019t you too old to be a virgin?\u201D she said and began to laugh uncontrollably. \r
Even though he felt slightly insulted, Shamsher continued. \u201CSince you\u2019re marrying me soon, I thought you should know that I have lost my job. Today.\u201D \r
As he tried to pull her back in his arms, he sensed the doubt in her body instantly. Bhanu pushed him back gently and with a questioning smile asked, \u201CDo you think you\u2019ll get it back? Or do you have other plans?\u201D\r
\r
\r
Shamsher wasn\u2019t sure of what to say, everything had moved so quickly that day that even light couldn\u2019t have caught it if it tried. \u201CI don\u2019t know,\u201D he said. \u201CDaddy ji\u2019s cousin had organized this job for me, I\u2019ll ask him when I meet him again if he can fix something else for me.\u201D Bhanu took a moment to think, then looked into his liquid green eyes and told him that she cannot do this. She said he was a lovely boy and she agreed to marry him because she thought he\u2019s moderately handsome and has a stable job. She worked at a beauty parlour herself but was aware that in these ambiguous times both partners have to earn to run a household efficiently. Bhanu added that she could go that extra mile if she was in love with him, but that wasn\u2019t the case yet. And she had dreams, that wouldn\u2019t let her take such a chance. \u201CI\u2019ll tell baba that I don\u2019t want to marry you, so he\u2019ll start looking again, I know,\u201D she added. \u201CShera, if you can find a decent job soon, before I say yes to someone else that is, come back. Otherwise, be good and look after yourself.\u201D\r
\r
\r
She was gone in an instant, if it were a poorly made Bollywood film it would surely have started raining right then.\r
\r
\r
---\r
\r
\r
If the wall outside his boss\u2019 cabin was around, Shamsher would have punched it another time. After standing on that terrace, motionless, for some time, when he finally stepped out into the world again, dusk had already set in. \r
\r
\r
For a while, he walked around aimlessly. Then when his phone began to ring nonstop, he understood Bhanu must have broken the news to her family already. Switching the device off, Shamsher walked towards a local watering hole. The place was always full at this hour, mostly with exhausted autorickshaw drivers and solitary formal-attired office-returning figures. After gulping down as many glasses of cheap rum he could get in a hundred bucks, he checked his pockets and discovered he still had about forty-seven rupees left with him. \r
\r
\r
Facing the watering hole was a superannuated film theatre that showed C-grade sex films, from Oriya to Kannada to Assamese \u2014dubbed in Hindi for easy consumption. This was the real melting pot of India, not Bombay. At the counter, he asked for a balcony ticket and got it for just thirty bucks. For the first time that day, he was pleased with something. Once inside, he realized that he hadn\u2019t even cared to ask for the name of the film that was playing. \r
\r
\r
The theater was nearly empty and there was no \u201Clightman\u201D in such places to guide you to your seat, assisted by his torch. But, Shamsher could hear the sound of soft moans coming from one particular direction in the dark. As he moved closer to that sound, he spotted a woman sitting on a man\u2019s lap, kissing him incessantly. Their faces were not visible. Their actions sloppy and repetitive; his passiveness made Shamsher anxious while her portrayal of pleasure infuriated him. In his head, he pictured Bhanu moaning in pleasure, riding some stranger in a filthy cinema hall. Even though it filled him with all-consuming rage, he was a little surprised that the thought didn\u2019t make him sad.\r
\r
\r
While the dozens of empty seats awaited his arrival, Shamsher sat down next to them.\r
\r
\r
---\r
\r
\r
It was impossible to tell how long it had been since the film had begun. On screen, two bodies were wrapped around each other, a man and a woman lying on a rock next to a waterfall. The man with hunger on his face on top, the woman must have been so uncomfortable while filming the scene, he thought. Her back a battlefield, with the sun right above them. But they looked calm and full of desire, like professionals who would suffer but not cheat their audience. In comparison, what unfolded next to Shamsher seemed like a pair of infantile birds who wanted to fly but couldn\u2019t gather enough courage to take that leap. \r
\r
\r
The woman\u2019s hands moved swiftly, rummaging through the buttons and seams of his shirt. But the man\u2019s eyes moved from her to the screen and again back to her, in a manner that said if given a choice he would rather watch the film than make love to the one in his arms. If any of Shamsher\u2019s friends had narrated this to him, they would have mocked the guy in the story, called him things like feeble and unmasculine. But this was a narrative unfolding with him as a character in it, and at that very moment Shamsher knew if someone had replaced the man and the woman with him and Bhanu he would have done the same, what the man next to him was doing; feigning attention while his mind was flaneuring some distant planet where no earthly rules apply.\r
\r
\r
A phone rang a couple of times a few minutes later, the woman took it out of her purse and ran towards the exit door. The man\u2019s eyes followed her until she was gone. When he turned, a smile was already appearing on his face before even he had fully looked at Shamsher, as if he knew their eyes were meant to meet. Shamsher didn\u2019t smile back. When the woman returned, she sat next to the man on the other side and said to him, \u201CDaddy wants me to be back home soon, let\u2019s leave?\u201D The man thought for a second and replied, \u201COkay, but just five more minutes, please.\u201D \r
\r
\r
She readily agreed and held his face to kiss him again. The man\u2019s face was turned away from Shamsher now, and even though Shamsher\u2019s eyes were fixed on the screen he sensed a touch on his right arm. A hand, searching for refuge but so quietly like a snake slithering into a prey\u2019s lair before striking. Shamsher didn\u2019t move his muscles, he held his breath as the man\u2019s fingers traced his arm, reached for his hand, and asked a question nobody had asked him before. Shamsher allowed his own hand to fold into the man\u2019s palm. The city wasn\u2019t always kind to lovers, that\u2019s why strangers had learnt how to be kind to each other. Like that poet who had to write what\u2019s difficult, because otherwise it was too difficult for him to write.`},{Type:"Bio",Text:"Sayantan Ghosh lives and writes in New Delhi, where he works as a senior commissioning editor for a publishing house. His work has been published in _Ambit Magazine, Electric Literature, Litro Magazine, The Aerogram, The Missing Slate, The Telegraph, National Herald, The Hindu Business Line, and The Times of India,_ among others, and his stories were longlisted for the DNA-Out of Print short fiction prize in 2014 and 2017. He was also shortlisted for the Editor of the Year award at the Publishing Next Industry Awards 2021.",photo:"Sayantan_Ghosh.jpg"}];var a={title:e,blocks:t};export{t as blocks,a as default,e as title};
