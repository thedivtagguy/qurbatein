const e="Habits",n="true",r=[{title:"Habits",blocks:[{Type:"text",Text:`You are a habit\r
which has overstayed in my head\r
like a nicotine rush that no longer arrives\r
when I puff on a solitary cigarette\r
at a chai stall\r
installed in an anonymous corner of a busy street\r
where the city never sleeps\r
\r
\r
But amid the cacophony\r
of cars rushing home\r
on the street beside my window\r
as they escape past another midnight\r
the thoughts of you keep me awake\r
like an insomnia\r
induced by a desire\r
I don\u2019t understand enough to write about yet\r
\r
\r
The dreams I have about the city\r
are now infiltrated by your presence\r
like the crevices and cracks on pavements\r
that lend them the character\r
clever concrete never could on its own\r
even as you seek to leave them behind\r
\r
\r
\r
\r
Is there enough space for me\r
in a heart you have let overrun\r
by your grief for a home\r
that will never exist or house any memories\r
beyond the sign carrying your surname\r
which hangs outside the door\r
you have spent your years hiding inside\r
yet could never be farther distance away from?\r
\r
\r
Maybe\r
the best way to discover ourselves in this city\r
infected by the indifference of living\r
is to rediscover the joy\r
of losing ourselves in each other\r
and of you making me another habit\r
which will overstay its welcome soon enough`}]},{title:"On Seeking Out the City",blocks:[{Type:"text",Text:`The city has violated me\r
Like the cars that drive past red lights\r
With no consideration\r
Of whom they leave behind in their trail\r
\r
\r
I have violated the city\r
And its desire for order\r
By seeking love that does not require\r
Giving oneself up\r
As the first step to intimacy\r
\r
\r
The secrets that lurk\r
In the hidden streets of all neighbourhoods\r
Have been discovered by lovers\r
Harbouring secrets of their own kind -\r
Enjoined within their palms\r
Which blend the borders between its creases\r
Like the spaces they inhabit\r
For satiating their own desire\r
\r
\r
I have sought the city out\r
In the hopes of finding desire around its corners\r
Filmed on the cameras\r
And of finding lovers\r
Lost before I have found them\r
With both of us staring out\r
The wrong end of lenses\r
As we capture all about the city\r
We could never capture in each other\r
\r
\r
The city has violated me\r
Like its poetry\r
Which writes rhymes into my heart\r
Without me knowing enough about them\r
To discover their schemes myself -\r
Or all the times it breaks them\r
Like cars driving past red lights\r
Situated in in the city\u2019s heart\r
Down the roads never built for us\r
To reveal to each other\r
\r
\r
Not within the confines of this city anyway.`}]},{title:"A Language I Could Only Speak with You",blocks:[{Type:"text",Text:`I learnt a language I could only speak with you\r
never to be found on the signs\r
that help us navigate our way through the streets\r
built like tunnels out in the open\r
yet trapping our hearts within its weary maps\r
for the sanity of our weary minds\r
\r
\r
I learnt a language I could only speak with you\r
away from the diction of desire the city\u2019s taught me\r
found on the movie posters that adore old walls\r
weathered into their crevices by time\r
leaving behind a signature of all they have to say\r
even as its heroes never gaze back into my eyes\r
\r
\r
I learnt a language I could only speak with you\r
hidden from the tongues of those who have inquired\r
whether I love the city or anyone in it:\r
I have always sought words they will understand\r
without ever letting go of the ones just the two of us share\r
revealed in glances that speak a thousand words\r
\r
\r
I learnt a language I could only speak with you\r
and a humour just the two of us can comprehend\r
for a love not foresaken in favour of a desire\r
that grips the hearts of fellow wanderers around me\r
infused within the same streetlamps we glance at\r
which protest the night when we walk underneath them\r
\r
\r
I learnt a language I could only speak with you\r
but we lost it the day I chose to love the city over us\r
\r
\r
We now only speak with the same phrases as everyone else\r
still, we remember how we swore at each other in jest\r
with the same glances that wrote unspoken words of love\r
\r
\r
Maybe someday, somewhere, we will weave poetry together again\r
within the confines of a city that never understood us\r
and with a tongue of our own\r
we can never fully comprehend either.`},{Type:"Bio",Text:"Abhijato Sensarma is an undergraduate student at Ashoka University, Sonipat. His words have been published in Scroll.in, The Wire, The Quint, ESPNcricinfo, McSweeney's Internet Tendency and Film Companion among other publications.",photo:"Abhijato_Sensarma.jpg"}]}];var t={title:e,multiplePoems:n,poems:r};export{t as default,n as multiplePoems,r as poems,e as title};
