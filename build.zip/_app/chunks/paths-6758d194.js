let a="",e="";function t(s){a=s.base,e=s.assets||a}export{e as a,a as b,t as s};
