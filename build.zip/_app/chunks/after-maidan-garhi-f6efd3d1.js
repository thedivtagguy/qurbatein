const r="Akhil Katyal",n="true",e=[{title:"After Maidan Garhi",blocks:[{Type:"text",Text:`everyone grows thorns\r
to protect themselves.\r
\r
\r
Under your feet\r
the stones\r
are no longer stones\r
but foothills\r
\r
\r
land is\r
unintended cricket fields\r
then dust\r
then leopard pugmarks.\r
\r
\r
This is the desert\r
signing you in\r
\r
\r
slowly\r
through kikar's checkpost.\r
\r
\r
They call it the devil tree\r
they call it the mad one\r
_Vilaayti Kikar_\r
\r
\r
it asks you for water.\r
\r
\r
The British brought it from Mexico\r
to Delhi in the 1920s,\r
making a mistake the size of kings.\r
\r
\r
It choked all trees around it,\r
it stole their water.\r
\r
\r
I walk cautiously in its dust\r
mindful of geckos,\r
\r
\r
find a tree\r
the size of my mistakes\r
leave your memory \r
on a low branch.\r
\r
\r
A slow wind\r
lifts the dust on its arms.\r
\r
\r
As I return\r
groundwater recedes\r
\r
\r
further\r
and then further.`}]},{title:"Night sounds at Safdarjung Tomb",blocks:[{Type:"text",Text:`The rasp of the jhingurs scraping \r
their forewings behind the hibiscus. \r
The floating arguments of the mynas \r
\r
\r
returning to their nests. The prowling \r
echoes of the skelter bats. The headlit\r
horns whetted by a red signal outside.\r
\r
\r
The alert clicks of a camera in the small\r
hands of a curly-haired novice. His chalein \r
to a friend when they\u2019re done. The shuffle \r
\r
\r
of their feet on old gravel. The footsteps \r
of the short guard minding the stanchions,\r
keeping a stray couple from the night. \r
\r
\r
A parrot\u2019s drop, light as a kerchief, in the hauz, \r
the sandstone of the tomb suddenly rippled.\r
The quiet press of a band of pigeons on the \r
\r
\r
dome drawn by an expert Abyssinian hand. \r
The guards discussing their change of duties. \r
The anomalous graze of a landing on a nearby \r
\r
\r
air-strip. Under the rococo sky, the disturbed \r
sleep of the Wazir-ul-Mamlak-e-Hindustan.\r
On my shoulder, the thin crush of your whisper.`}]},{title:"How rivers cross their cities",blocks:[{Type:"text",Text:`Near a church in Karrada,\r
the Tigris takes such a sharp turn\r
as if it doesn\u2019t want to \r
leave Baghdad.\r
\r
\r
The Lyari in Karachi\r
(on the other hand) can\u2019t be\r
bothered to stay.\r
\r
\r
Through Delhi,\r
Yamuna is a moral lesson\r
clear as day: _life is tough_,\r
first a trough, then a crest,\r
then a trough.\r
\r
\r
The Chenab, \r
knowing better, walks on stilts, \r
keeps a one-arm distance from Jhang.\r
\r
\r
The Ganga \r
covers Patna like a quilt.\r
\r
\r
The Gomti baby bumps\r
through Lucknow.\r
\r
\r
And when it\u2019s about to leave,\r
for a last look at Chennai,\r
the Adyar turns.\r
\r
\r
As the Ravi \r
cold-presses the cheek\r
of Lahore that burns.`},{Type:"Bio",Text:"Akhil Katyal grew up in Bareilly and Lucknow and currently lives in New Delhi. In 2016, he was an International Writing Fellow at the University of Iowa. His first book of poems, _Night Charge Extra_, was shortlisted for the Muse India Satish Verma National Award, 2015. He has translated Ravish Kumar\u2019s book of Hindi love stories, _Ishq Mein Shahar Hona_, as _A City Happens in Love_ (Speaking Tiger, 2018). He teaches Creative Writing at Ambedkar University Delhi. _How Many Countries Does the Indus Cross_ is his second book of poems.",photo:"Akhil_Katyal.jpg"}]}];var t={author:r,multiplePoems:n,poems:e};export{r as author,t as default,n as multiplePoems,e as poems};
