const e="Angana Sinha Ray",a="Tu Kisi Rail Si",t=[{Type:"pullquote",Text:`Tu kisi rail si guzarti hai.\r
Mai kisi pul sa thar-tharata hu.\u2019`},{Type:"text",Text:`Tu Kisi Rail Si \r
\u2018guzarti hai, \r
Tu kisi rail si guzarti hai.\r
Mai kisi pul sa thar-tharata hu.\u2019[1]\r
\r
\r
Sonku has vivid dreams in August and blames the humidity. The visions from last night have deeply moved him. Swanand Kirkire draped in Sonku\u2019s mother\u2019s saree, crooning him to sleep. When he narrates this to Shobha in the morning, she is part-amused, part-flabbergasted.\r
\r
\r
\u201CYe Swanand Kirkire hai kaun?\u201D[2]page\r
\r
\r
Sonku pulls out his phone and yells into it, delighted every time Google recognizes his enunciations. He is a big city man now; it is only fair his voice echoes the metropolitan \u2013 clear enunciations with space bars in all the right places. \r
\r
\r
\u201CLook! This is Swanand Kirkire.\u201D\r
\r
\r
Shobha lets out a large laugh, perhaps stirring a quarter of their neighbours from their slumber. It is a Sunday morning; the city is waking one limb at a time. The only sounds are from the garbage truck loudspeakers serenading the streets. There are no children to be fed and sent to schools today, no husbands with their hoarse groaning or gross alcohol breaths, no parathas to be flipped at this hour, or tea cups to be washed, or clothes to be thrashed, not yet, not this very minute. \r
Shobha mocks Sonku as she tucks her saree in, struggling to fasten the drape over her navel. Sonku knows this is not an aesthetic choice, but one born out of practicality. Shobha cannot afford the saree accumulating the untarred roads in its folds, it is already starting to fray. One day, Sonku will buy her a grand green saree with intricate kaarigari. There\u2019ll be none of these unshapely pebbles and gutka wrappers and cow shit on their way to the world. So much for this terrible Swachh Bharat Abhiyaan song! If the streets cannot be scrubbed off the indented cow shit, the shrill high frequency music should at the ll very least blow away some of the plastic wrappers, no? Imagine the Rajnigandha and Shikhar wrappers scurrying around like a defeated army, marching away to Kailash Kher\u2019s voice. Sonku smirks in his head. \r
\r
\r
But no, Shobha\u2019s drapes must stay intact. One day, there'll be a nicer house, encircled by wide streets like the metro stations. The deep grey tiles of the Noida Sector 50 Rainbow station are the exact shade of August clouds, late monsoons condensed with unforeseen ferocity, as if on a deadline to drench the city. Sonku\u2019s neighbours dread the downpour, last year it rained so hard, even the stubbornest of the cow shit unhinged itself from the side-lanes and floated into Monu\u2019s kitchen. It was days before the house could be salvaged. Sonku remembers spraying the house with old talcum powder to offer the delusion of a disinfectant. \r
\r
\r
And yet, the greying sky never dissuades Sonku, everything can be scrubbed clean with adequate effort. One day Sonku will have a house that doesn\u2019t touch the ground, it won\u2019t be as elevated as the Noida Sector 50 Rainbow station but high enough to eschew the cow shit altogether.  He\u2019ll ask the housekeepers at the metro station today about their brand of cleaning products, how they keep even the greyest of tiles so glossy. In his new home, the tiles must glimmer. You can see your reflection on the floor, there\u2019ll be no room for mirrors, no requirement at all. Sonku will wake up and plant his feet on the floor, glance at his face smiling back at him.\r
\r
\r
It is important after all, for men to have witnesses to them becoming men. \r
\r
\r
\u2026\u2026\u2026.\r
\r
\r
It is so taxing to fill up a 42-inch shirt! Ask Sonku who has moved from 38 to 40 now, all thanks to the push-ups! But the small hands, the damned small hands! When Sonku undresses every evening, Shobha often marvels at his shoulders; but he is quick to retort, \u201CYes, but look at my hands! So tiny! Your hands are bigger than mine!\u201D \r
\u201CArey! Tumhaari tareef karo tou badley me gaali milti hai! Mere haath mere papa jitney badey hai. Meri saari behney milke hasti hai mujhpe. Tumhe kya pata? Kaash mere haath tumhaare jaise hote..\u201D[3]\r
\r
\r
\u201CThat\u2019s because my hands are of a woman\u2019s!\u201D\r
\r
\r
\u201CAb mere haath mard jaise hai, tumhaare haath tumhe lagta hai aurato jaise hai. Kya farak padta hai? Bhagwaan ne jo bhi dia hai, wo kuch soch samajhke hi dia hoga.\u201D[4]\r
\r
\r
Sonku isn\u2019t quick to lose his temper, but _bhagwaan\u2019s_ fixities tire him. God himself, amorphous, vast, perhaps both a panther and a phantom. But his people \u2013 all obstinate peels of skin, painstakingly slow shoddily packed organs drudging towards personhood, only to fail. \r
\r
\r
_Wrong body wrong! Body Wrong! Body betrays! Body betrays mind, speech betrays heart, heart betrays preservation, preservation betrays body, body betrays mind betrays speech betrays heart betrays preservation betrays body collapses mind berates speech breaks heart circumvents preservation empties body small body wrong body no body nobody no body nobody no body nobody no body._\r
\r
\r
\u201CHow dare you! What do you mean by bhagwaan ne jo dia hai?[5] God is an idiot!\u201D, Sonku breaks down and storms out of the room, slamming the door on Shobha. Her last boyfriend would have smacked her across the face had she displeased him, Sonku would never. She knows there are only two sorts of men in pain \u2013 ones who break themselves, and ones who break their lovers. Her last boyfriend didn\u2019t break her but bent her arm so hard that her elbow now permanently points outwards from her body, as if anticipating a crisis and ready to run before the rest of her. No matter how hard she pulls it towards her, the elbow always escapes, towards the window, the door, even the exhaust fan sometimes. Every opening out in the world is a fire exit for her elbow, Shobha burns with shame. Sonku would never, Sonku breaks himself so he must be a good man. \r
\r
\r
I didn\u2019t mean it like that, she taps the door with her palm, you know how I meant it. I meant, I meant I love you! I don\u2019t care how God put you together, or put me together, but God put us together and I\u2019m grateful, I just meant, \u201CMai tumse pyaar karti hu. Please darwaaza kholo, gussa mat karo mujhpe, mujhse galti ho gai! Bhagwaan se bhi ho hi jaati hogi, maaf kar do, khaana thanda ho raha hai.\u201D[6]\r
\r
\r
She presses her ear to the door, Sonku\u2019s muted wailing slips through the cracks. \r
\r
\r
\u201CGod is extremely unkind. God knows I\u2019m a man and still gave me such a large chest!\u201D\r
\r
\r
\u201CBut you are a big city man, aren\u2019t you?\u201D Shobha consoles Sonku, it works only when she lowers her voice to a murmur, to an absence. \u201CThink of it this way, big broad men have big broad chests. All the sahibs will look up to you.\u201D\r
\r
\r
Sonku laughs between sobs, endeared and re-assured. Shobha is grateful, not for the calm, but the script of arguments. Familiarity breeds contempt only with small disappointments, like forgetful lovers, anticipating everything they will forget despite reminders. Festivals, money to be sent home, rent to be paid by the 5th of every month \u2013 small damages and negotiable resentments.  The ones you can bribe your heart out of saying, \u201CYou know, he loves you, so what if he is forgetful?\u201D The problem with Sonku is that he remembers, Sonku never forgets groceries, nor the rent, or her birthdays. But he also remembers the skin, scrutinizes it in an uncanny resemblance to how Shobha sieves the atta off dead bugs. \r
\u201CMy body crawls up onto me.\u201D he says, \u201CIt\u2019s icky.\u201D\r
She requests him to sing. \r
He needs to shower.\r
\u201CKabhi aur, another time.\u201D \r
Shobha tells herself the same, kabhi aur, another time, it will get better. \r
\r
\r
\u2026\u2026\u2026.\r
\r
\r
\u2018Tu kisi rail si guzarti hai,\r
Mai kisi pul sa thar-tharata hu\u2019\r
\r
\r
The song is stuck in Sonku\u2019s head and he is busy memorizing the lyrics. When he was younger, his mother had noticed his passion for Kumar Sanu\u2019s songs, and saved up to buy him a harmonium. By the end of that year, Sonku could sing every Sanu song by heart. Now, he remembers the melody but has forgotten the lyrics. Ever since he has taken to mumbling instead of speaking, his memory has let go off the words that hit the high notes. He understands how boys become men now, they start mumbling so they can\u2019t hear their own agonies. He has only done the same. \r
\r
\r
Becoming a man, Sonku has realized, is about selective listening. In the last two years, Shobha has heard him sing approximately five times. All her other requests have been ignored, misplaced, deferred to the endless horizons of \u201CTumhaare bhai ke shaadi pe\u201D[7], \u201CHumaari saalgirah pe\u201D [8], \u201CMehmaano ke liye\u201D [9]\r
\r
\r
But this time, he has promised to sing Swanand Kirkire\u2019s song on Raksha Bandhan when he visits Shobha\u2019s brother to pick her up at the end of the day. Shobha\u2019s brother likes him, an honour he cannot afford to take lightly; best to prepare in advance. The song, he believes, was written for him, just the metro instead of the train - the metro and the lover the same thing \u2013 both rushing towards the world at 6am with unparalleled urgency, both terribly restless and incapable of resting. But despite going in circles, always returning at the end of the day \u2013 quiet all of a sudden. Sonku adores their reliability. Neither the metro, nor Shobha are ever late unless there's flooding in the city. \r
\r
\r
But Shobha hates the metro, calls it her \u2018sautan\u2019[10] since Sonku\u2019s affections are split between the two of them. She tells him how the metro\u2019s grumblings make her feel as though she has an upset stomach herself. \r
\r
\r
\u201CArey! Aadat ho jaati hai.[11] Shobha, you end up listening to such bizarre conversations in the mem-sahibs\u2019 homes. I don\u2019t know, there\u2019s something self-reliant about the metro, it is its own master. And the sounds, so much better than these lonely women you work for, forcing you to hold a conversation, whining about their husbands and\u2026\u201D\r
\r
\r
\u201CTum naukri me baithe baithe bohot sarkaari advertisements sunn rahe ho aaj kal! Self-reliant! Sarkaar tumhaare dil me aa gaya hai.\u201D[12]\r
\r
\r
\u201CThe sarkaar is really trying! Society takes a lot of time to accept people like me, it\u2019ll take ages. But at least the sarkaar is giving jobs! It will change slowly-slowly. And it is a good job. It is a desk job, I get to sit in the air conditioner all day and all I have to do is make sure I give them the right tickets. Nobody even thinks about whether I\u2019m a man or a woman. And they call me \u2018bhaiyya\u2019, or \u2018bhaisaab\u2019.[13] All I do is keep my voice a little low\u2026\u201D\r
\r
\r
That is because everybody is in a rush! \u201CJaldbaazi, jaldbaazi! Mujhe pasand nahi!\u201D[14]\r
\r
\r
\u201CBut the rush hour is the best part of my job! People don\u2019t care to even look at me, nobody sees your small hands in _jaldbaazi_, you know? You, on the contrary, have to be around the mem-sahibs all day, look how much you have to do!\u201D \r
\r
\r
\u201CRasoi chalane ki aadat hai mujhe.\u201D[15]\r
\r
\r
\u201CRasoi chalana! Dil behlaana![16] Look at all the nonsense these mem-sahibs tell you. They\u2019re always telling you to do better \u2013 make softer rotis, press their backs harder, lift more grocery bags! Then they complain about their husbands always being out of town! And get mad when you don\u2019t have terrible things to say about me. I don\u2019t have to deal with any of that when I\u2019m selling tickets. I do not have to talk to anyone long enough, you have to stick around!\u201D \r
\r
\r
Sonku is a man of velocity \u2013 he has learnt this from the metro too, whooshing by so loud that it lacerates words, pleasantries, questions, everything. The joy of being severed from language!\r
\r
\r
\u201CPata nahi, station dekhke mera dil ghabrane sa lagta hai. Log ghoorte hai bohot. Chhoote hai bohot. Tumhe ajeeb nai lagta?\u201D[17]\r
\r
\r
\u201CWhat is wrong with that? People have to be frisked before entering! I can\u2019t think of any other mechanism\u2026\u201D\r
\r
\r
\u201CMujhe barriyaar nai pasand!\u201D[18]\r
\r
\r
\u201CBarrier? Barricade?\u201D\r
\r
\r
\u201CHaan, bilkul police jaisi feeling aati hai. Itni security kis baat ki?\u201D[19]\r
\r
\r
\u201CBut what if there are goons? The metro is like the sarkaar only. Like democracy only. Everyone is allowed. Only not goons, people who create disturbance. All this frisking and camera business is for safety reasons only. So they know that no one is creating ruckus, misbehaving, doing all of that.\u201D \r
\r
\r
\u201CMai camera ke baare me kuch bol hi nahi rahi, Mujhe bas wo police waali aurato ke saath achha nai lagta. Bematlab hi! Hamesha gusse me rehti hai. Bohot chhedh-khaani jaisi feeling aati hai!\u201D[20]\r
\r
\r
\u201CChedh-khaani? That is normal only baba, normal frisking\u2026 so you\u2019re not carrying any knives or guns or drugs. Safety ki baat hai, tum samjho na!\u201D \r
\r
\r
\u201CEk baar pata hai, ek mem-sahib ne apna puraana coat mujhe de dia tha. Aur wo lady security ne mujhe har jagah chho-chhooke dekha, jaise mai kuch chhupa rahi hu. Peechhe lambi line lag gait hi. Itni sharam aai thi na mujhe..\u201D[21]\r
\r
\r
 \u201CI know those people, security guards, they aren\u2019t bad people. But work is work, no? They have to do it. And anyway, women don\u2019t touch other women in a bad way, you know? I know you think you were being examined so closely, and it is not just the metro, it is everywhere. Even the government has to do these things. It is a mechanism for safety, information. Look, the government just has to be safe, we are such a large country, they just want to know\u2026And then they try what they can. Now look at this Trans Bill, took so long, the government had to do its own examinations, but ultimately I got this job na?\u201D\r
\r
\r
\u201CLekin itni hich-kich hui tumhaari certificate ko leke! Kitni mehnat! Tum society se itne chidhte ho\u2026 sarkaar aur metro se itna pyaar karte ho.\u201D[22]\r
\r
\r
\u201CThe sarkaar and metro does everything fatafat!23 From one destination to the other, resolving issues quickly. Society is so slow, I can\u2019t stand people!\u201D\r
\r
\r
\u201CKaafi log waise Bill ke khilaaf hai, suna maine\u2026\u201D[24]\r
\r
\r
\u201CNot people, not the whole community community, only transwomen. Kuch auraton ka to kaam hi hai, maamle ko bade scope me na dekhke chik-chik karna!\u201D[25]\r
\r
\r
\u2026\u2026\u2026.\r
\r
\r
On the day of Raksha Bandhan, the plan is simple. Sonku takes the early morning shift and hopes to wrap up by afternoon. Shobha has managed to take a leave from most of her employers, barring one old woman who needs Shobha to cook her breakfast. After which, Shobha will board the metro from the Noida Rainbow station itself to head to her brother\u2019s. Sonku\u2019s heart is drumming like a hammer. This is the first time Shobha will see him at work, in one of the white shirts she has ironed to an immaculate crispness. Sonku finds himself distracted between punching tickets, constantly rolling his sleeves up and down his elbows, figuring out the most flattering degree to expose his forearms. He can\u2019t wait for Shobha to buy a ticket from him, he\u2019s told her that she must hide the fact she knows him, that he must appear cool and professional, even though his cheeks are flushed. He taps his feet constantly. in impatience, shakes his thigh under the table so hard that the entire desk vibrates. Then he punches a wrong ticket and the traveler has to return, this has never happened before, he is a little taken aback but it\u2019s alright! The certainty of return is a good sign, the metro runs even on holidays, Shobha will show up despite her hatred for it, Sonku will sing once again, the sarkaari naukri\u2019s contract will be renewed once again, how can it not? He is a good man, a good employee, a good citizen. \r
\r
\r
Two hours pass and there is no sign of Shobha, perhaps the old woman has asked for an exquisite breakfast. What could it be? The woman can barely chew poha anymore. Perhaps she decided to change her saree, wear the lovely green one he has bought her recently. Perhaps she ran out of sugar for the kheer, her brother is addicted to it after all. He takes three full tablespoons of it in his tea every day\u2026 Sonku is running out of excuses. His thighs have gone limp from all the shaking but his heart is anxious, what if\u2026\r
\r
\r
A thin shriek lacerates the metro\u2019s grumbling, sharp a jeweler\u2019s aim piercing an earlobe, all sound evaporates for a few seconds, the station comes to a standstill. Sonku abandons his desk much to his co-worker\u2019s chagrin and rushes to the entry point. Shobha is in tears, clinging onto a plastic bag dripping with kheer. The woman security guard is gripping the hand metal detector like a gun, poking it at Shobha\u2019s elbow.\r
\r
\r
\u201CGadhi aurat hai kya? Kheer ka dabba tak band nai karna aata tujhe! Poore conveyor belt ko kachdaa karke rakh dia. Tu dhoyegi ab?\u201D [26]\r
\r
\r
Another woman, a face indistinct from Shobha\u2019s mem-sahibs, taps her heels on the tiles, \u201CThis lazy woman! Who lets you enter here? Will you pay for your kheer spilling on my bag? Get her out of here.\u201D\r
\r
\r
Shobha stifles her sob, \u201CMadame, please.\u201D, the only two words she pronounces correctly in English, \u201CMadam please, maaf kar do. Wo maine dhakkan lagaya tha kaske, subah se ek badhi tiffin box dhunde jaa rahi thi\u2026 Aaj Raksha Bandhan hai, please maaf kar dijiye, mere bhai intzaar\u2026\u201D[27]\r
\r
\r
\u201CMy god she talks a lot\u2026\u201D, the memsahib turns towards the security guard, \u201CNikaaliye inko!\u201D[28]\r
\u201CSuna nahi? Nikal yaha se nai to hazaaro ka kharcha ho jayega tera! Haath ka to ilaaj nai kara paayi\u2026\u201D[29], the guards laughter soars, collaborates in the humdrum with the train passing overhead. Sonku counts the trains passing overhead, wondering how many it takes to muster the courage. \r
\r
\r
\u201CDekhiye, mere husband yaha kaam karte hai, ek baar bula dijiye unhe.\u201D[30]\r
\u201CArey nalayak aurat! Futt yaha se! Line ruki hui hai tere wajah se!\u201D[31]\r
Sonku, though shivering, finally steps in, hoping his broken English will salvage Shobha\u2019s bent elbow. \u201CJaane dijiye unhe, let her go.\u201D\r
\r
\r
Shobha wrestles her elbow out of the guard\u2019s grip, Sonku will save her now. She would\u2019ve dashed towards him immediately, had his eyes not been steel, like metal armour. All these polished elevators, glass doors, cutting-edge security cameras, not to watch over people but to hide cowards, she sees it now. And lowers her head, once again.\r
\r
\r
\u201CExcuse me, who are you?\u201D\r
\u201CI work here\u2026 I am the\u2026\u201D\r
\u201CSaab, aap desk pe jaaiye, supervisor gussa ho jaayenge. Aap dakhal-andaazi mat kijiye. Tameez se inko ghar jaane ko bol rahi hu, bohot damage kar dia inhone\u2026\u201D[32]\r
\u201CYe to saaf ho jayega, metro to sabka hai na? Aisi cheezein\u2026\u201D[33]\r
\u201CHello? She has ruined my bag. Will you pay for it?\u201D\r
Sonku doesn\u2019t notice Shobha slinking away, one slow step at a time, her back turned towards him. He wants to scream to shut up his colleagues, but all he manages is, \u201CMadam, aap ghar jao, yaha\u2026\u201D 34\r
\r
\r
She is almost a speck now, the clouds are darkening and it might pour again. Long-term safety, he thinks, he can\u2019t lose his job, they need a big house higher than the ground level so the water doesn\u2019t clog. Shobha can choke her tears for now, and he returns to his desk. \r
In the evening when he comes back home, ready to apologise and explain, Shobha shakes her head and refuses. \r
I just have one request, \u201CAaj mere liye gaana gaao.\u201D[35]\r
\u201CBas itna hi? Batao kya sunna chahti ho? Tumhaare liye to aaj\u2026\u201D[36]\r
He is relieved, Shobha understands after all. But when he tries to touch her, she moves a step away. Her eyes are turned towards the exhaust fan.\r
\u201CWo tumhaare Swanand saab waala\u2026\u201D\r
\u201CTu kisi, tu kisi rail si guzarti..? Haan, gaata hu\u2026\u201D[37]\r
\u201CNai!\u201D, she cuts him. He tries to face her but her eyes keep evading him, only her elbow pointed towards him, as if a warning to not come closer. \u201CAgla line. Gaate raho, baar baar, rukna mat\u201D38\r
\r
\r
\u201CMai kisi pull sa thar-tharata hu.\r
Mai kisi pull sa thar-tharata hu.\r
Mai kisi pull sa thar-tharata hu\u2026\u201D[39]\r
\r
\r
The sky thunders over Sonku\u2019s voice. His body shakes into tears, he raises his head and lets out all the voice from the core of his stomach, for all the times he\u2019s mumbled. He sings into the vast emptiness he knows now. The sky shatters without mercy, he doesn\u2019t stand a chance.`},{Type:"Bio",Text:"Angana Sinha Ray is a master's student in English Literature at Ashoka University. Her works have previously been published in The Raiot, The Bombay Literary Magazine, The Equator Line, and The Remnant Archive. She hopes to engage with translation studies in the future.",photo:"Angana_SinhaRay.jpg"},{Type:"footnotes"}],o=[{type:"text",value:"1.  You pass like a train, I shudder like the bridge left behind. Swanand Kirkire\u2019s song for Masaan (2015)"},{type:"text",value:"2.  \u201CWho is this Swanand Kirkire?\u201D"},{type:"text",value:"3.  \u201CIt\u2019s not good praising you, I praise you and you cuss back. My hands are as big as my father\u2019s! All my sisters laugh at me. What do you know? I wish I had hands like yours.\u201D"},{type:"text",value:"4.  \u201CMy hands are like a man\u2019s. And you think yours are like a woman\u2019s. How does it matter? Now whatever God has given us, He must have thought it through.\u201D"},{type:"text",value:"5.  \u201CWhat do you mean by \u2018whatever God has given\u2019?\u201D"},{type:"text",value:"6.  \u201CI love you. Please open the door. Don\u2019t be mad at me, I know I made a mistake. Even God might make mistakes sometimes, please forgive me. Please come eat, the food will get cold.\u201D"},{type:"text",value:"7.  \u201CYour brother\u2019s wedding\u201D"},{type:"text",value:"8.  \u201COn our anniversary\u201D"},{type:"text",value:"9.  \u201CFor the guests\u201D"},{type:"text",value:"10.  The other wife/lover of one\u2019s husband"},{type:"text",value:"11.  \u201CIt becomes a habit.\u201D"},{type:"text",value:"12.  \u201CYou\u2019ve been listening to a lot of government advertisements at work these days! Self-reliant! The government has won your heart!\u201D"},{type:"text",value:"13.  Brother or elder brother"},{type:"text",value:"14.  \u201CAlways a haste! I don\u2019t like it!\u201D"},{type:"text",value:"15.  \u201CI\u2019m used to the kitchen.\u201D"},{type:"text",value:"16.  \u201CRunning the kitchen! Then pleasing them for their non-sense!\u201D"},{type:"text",value:"17.  \u201CI don\u2019t know, I always feel anxious in the stations. People stare a lot, touch a lot. Don\u2019t you find that strange?\u201D"},{type:"text",value:"18.  \u201CI don\u2019t like the barrier.\u201D"},{type:"text",value:"19.  \u201CIt feels like the police! What is all this security for?\u201D"},{type:"text",value:"20.  \u201CI am not even talking about the camera. I just don\u2019t like being touched by the security women. It always feels like they are angry, I feel harassed.\u201D"},{type:"text",value:"21.  \u201CThis one time, a mem-sahib gave me an old coat of hers. And then in the metro, the woman security guard examined me closely, touched me everywhere, as if I was hiding something. There was a long line waiting behind me. I was so ashamed..\u201D"},{type:"text",value:"22.  \u201CBut it was such a trouble getting your certificate! So much effort! You hate people, you only love the government and the metro.\u201D"},{type:"text",value:"23.  Quickly"},{type:"text",value:"24.  \u201CMany people are against the bill, I\u2019ve heard\u201D"},{type:"text",value:"25.  \u201CSome women do this, they don\u2019t see things in a larger perspective, and start getting impatient!\u201D"},{type:"text",value:"26.  \u201CAre you dumb, woman? You couldn\u2019t tighten the lid of the container! There is kheer dripping on the conveyor belt! You\u2019ve turned it to garbage. Will you clean it now!\u201D"},{type:"text",value:"27.  \u201CMadame please, I\u2019m sorry, I made a mistake. I did tighten the lid. I\u2019ve been looking for a bigger tiffin box since morning\u2026 Today is Raksha Bandhan, please forgive me, my brother is waiting.\u201D"},{type:"text",value:"28.  \u201CGet her out of here!\u201D"},{type:"text",value:"29.  \u201CDidn\u2019t you hear her? Get out of here! Or you\u2019ll have to pay thousands for the damage! Look at you, couldn\u2019t even get your hand cured!\u201D"},{type:"text",value:"30.  \u201CLook, my husband works here. Can you please call him once?\u201D"},{type:"text",value:"31.  \u2018You stupid women! Just disappear from here! People are waiting, the queue is stuck because of you!\u201D"},{type:"text",value:"32.  \u201CSir, please go to your desk, the supervisor will be angry. You shouldn\u2019t interrupt here. This woman has no manners, she\u2019s done a lot of damage.\u201D"},{type:"text",value:"33.  \u201CThis will get cleaned up. The metro is for everyone. These things\u2026\u2019"},{type:"text",value:"34.  \u201CMadam, you should go home.\u201D"},{type:"text",value:"35.  \u201CSing for me today.\u201D"},{type:"text",value:"36.  \u201CThat\u2019s it? Tell me what you want to hear. For you I will sing\u2026\u201D"},{type:"text",value:"37.  \u201CTu kisi rail si\u2026 Yes, yes, I will sing..\u201D"},{type:"text",value:"38.  \u201CThe next line. Keep singing, don\u2019t stop.\u201D"},{type:"text",value:"39.  \u201CI shudder like the bridge, I shudder like the bridge, I shudder like the bridge\u2026\u201D"}];var n={"1":[],"2":[],"3":[],"4":[],"5":[],"6":[],"7":[],"8":[],"9":[],"10":[],"11":[],"12":[],"13":[],"14":[],"15":[],"16":[],"17":[],"18":[],"19":[],"20":[],"21":[],"22":[],"23":[],"24":[],"25":[],"26":[],"27":[],"28":[],"29":[],"30":[],"31":[],"32":[],"33":[],"34":[],"35":[],"36":[],"37":[],"38":[],"39":[],author:e,title:a,blocks:t,footnotes:o};export{e as author,t as blocks,n as default,o as footnotes,a as title};
