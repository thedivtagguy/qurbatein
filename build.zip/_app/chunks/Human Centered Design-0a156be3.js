const e="Human Centered Design",t="HCD";var n={title:e,major:t};export{n as default,t as major,e as title};
