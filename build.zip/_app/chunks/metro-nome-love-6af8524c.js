const e="metro-nome-love",r="For Ishika, Shivangi, and Shubham",n="false",s=[{Type:"text",Text:`Agla station \u2014 KASHMIRI GATE \u2014 hai\r
Next station is \u2014 KASHMIRI GATE \r
\r
\r
Rini and Shammi\u2019s luscious prophecies slip out of the speakers overhead, \r
and I am caressed gently out of a drugged dream by spurious sounds. \r
\r
\r
As the rich timbre of moving metal returns, I adjust my seated body \r
\u2014 straighten, stretch \u2014 and look about metro car no. 6. \r
\r
\r
Any sense of comfortable journeying I carried with me half-asleep is dismantled by a woman\r
weary of touch, coiled around a silver pole. Her clutch is covered by her perspiring right palm \r
and her hair needs adjusting, but Woman\u2019s choices have crippling consequences \u2014 \r
risk and arousal risk arousal momentarily.\r
\r
\r
Wearily Mother watches Son\u2019s virgin-lecherous eyes entwine themselves around silver pole no. 2, \r
where, inexperienced still, Schoolgirl fails to decipher gaze or avert smiles. Another Mother \r
smothers her weeping child with impeachable preaching and innocuous hugs, _but_ Child has a \r
child\u2019s mind: from somewhere someone somewhat sings and careless Child chimes.  \r
\r
\r
Ex nihilo Metro\u2019s ducts create an unnatural breeze and to dimmed car no. 6 bring peculiar ease.\r
Craving touch, crotch after crotch breathes \u2014 tensed muscles release and forget. _But_, how can I neglect attire? Around me tired feet wear tired footwear and tired fashion accents tired eyes trying to sleep away time \u2014  \r
slips away, slips away silently, all sense of a city being traversed, silently slips\u2026\r
\r
\r
GREEN PARK station\r
Doori ka dhyan rakhein\r
GREEN PARK station\r
Mind the gap \r
\r
\r
In metro car no. 6 \r
space shrinks \r
naturally\r
Man\u2019s gaze \r
is transfixed \r
on Another \r
Man\u2019s digital life\r
\u2014 \r
familiar notes erupt \r
in mechanical time\r
and how frantically \r
Another Man\r
now awake\r
births \r
new mobile \r
desires\r
let notifications wait some more\r
he ruminates \r
\u2014 \r
he conspires\r
\r
\r
Lugging luggage heavier than his heartache, Uncle resolves into restful attention, \r
_but_ finds no respite for his ancient legs. Brother\u2019s bother not about Uncle\u2019s exhaustion: \r
No offering in disguise this time \u2014 no space to sleep, to shut sorrow\u2019s eyes. \r
AND I, another brother,\r
staring solemnly out of the window at the endless passing edifices of concrete,\r
mutter to myself, \u201CMother and Measure - \r
Mother Law and Measure Law - \r
Mother Love and Measure Love - \r
thou art translated.\u201D\r
\r
\r
As Metro slices slithers slips across the expanse of Dilli, _meri jaan_, \r
the solace of a midsummer dream surprises me.`},{Type:"Bio",Text:"Salik is a Ph.D. scholar in English at Vanderbilt University. His poetry has appeared in netherQuarterly and Inverse Journal.",photo:"Salik_Basharat.jpg"}];var a={title:e,subtitle:r,multiplePoems:n,blocks:s};export{s as blocks,a as default,n as multiplePoems,r as subtitle,e as title};
