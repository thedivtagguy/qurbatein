const e="Arrival",n="false",r=[{Type:"text",Text:`under the susurrus on tin plated sheets\r
i stand listening\r
to the southwesterly winds \r
howling hymns to the land of the beloved\r
to the splashes of sleazy raindrops echo\r
from the inner chambers of the prayer hall\r
to the still water in the cisterns disturbed\r
by hands being cleansed for ritual\r
\r
\r
banana leafs careen laden with ripe fruits\r
golden with delight at the beloved\u2019s imminent arrival\r
cocks prick around thirsty\r
unquenched by the day\u2019s drizzle\r
the petrichor reminds me of untouched skin\r
waiting to be rubbed with sin\r
\r
\r
the scent of god breathes through\r
his pir-o-mones \r
rosy round kashmiri cheeks\r
redolent of their own apples\r
supple\r
slender\r
sexy\r
like a\r
serpent\r
\r
\r
under the dome of illumination\r
brightest chandelier of hope you are\r
the blazing sword of \u2018Alif pincers my heart \r
yet it is condensed with coolness\r
from the icy crypts that are\r
your hauntingly beautiful cold eyes\r
that commands the fire within\r
to be a breezy peaceful retreat\r
\r
\r
eyes of a philosopher\r
filled with fecund profound \r
possibilities\r
bedazzling the blandness\r
in my heart\r
\r
\r
draped in a friday prayer gown\r
telling the beads on my rosary\r
leaning on a pillar in the veranda\r
i look out onto the road\r
\r
\r
his motorcycle rumbles on the highway\r
puffing smoke ferociously\r
just like him on his jazz & joint nights\r
his voice intoxicates me\r
but i can\u2019t hear what he preaches\r
but he\u2019s my prophet on the pulpit\r
\r
\r
alas! but a juggernaut hits him\r
and his body tumbles\r
down, making my heart leap\r
\r
\r
my legs carry me to his bloodied head\r
glistening gushes of velvet red\r
stream from his conscious \r
he proclaims with the last puff of his breath\r
the antithesis of his faith\r
\u201Cthere is no God\u201D\r
\r
\r
\u201Cbut God\u201D i whisper to his ear\r
gently closing those eyelids\r
and kissing them\r
before i kissed those tender lips\r
not only the thirsty seek water\r
the water as well seeks the thirsty`},{Type:"Bio",Text:"Muhammed Raazi is a freshman in Ashoka University still figuring out and making sense of the world he was thrown into. Hailing from the Emirates, Karnataka and Kerala, his confrontation with multiple languages and cultures has widened his scope of perceiving reality yet he looks around him in perpetual childish wonder.",photo:"Muhammed_Raazi.jpg"}];var t={title:e,multiplePoems:n,blocks:r};export{r as blocks,t as default,n as multiplePoems,e as title};
